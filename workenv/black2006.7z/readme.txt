To be extracted in "C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Source\cstrike\custom\"

Only choose one variant of the seventh wave.